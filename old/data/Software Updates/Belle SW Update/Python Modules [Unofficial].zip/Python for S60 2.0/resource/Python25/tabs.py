__author__ = 'dimy44'

__doc__ = '''
# module tabs.py.

import tabs

# instance:
tab = tabs.Tabs()

#  parameters for tabs, setter only:
tab.tabs = ([unicode(item), ...], select_callback)
# or tab.tabs = [unicode(item), ...]
# or tab.tabs = select_callback

# number active tab, getter & setter:
tab.active_tab = 0

# activate or hide tab, getter & setter:
tab.visible = 1 # or 0
'''

__all__ = ('active_tab',
              'tabs',
              'visible')



import appuifw

class Tabs(object):
    
    __instances = []
    

    def __new__(cls):
        instance = object.__new__(cls)
        cls.__instances.append(instance)
        return instance


    def __init__(self):
        self.__callback = None
        self.__items = []
        self.__pos = 0
        self.__visible = 0


    def __call(self, index):
        self.__pos = index
        try:
            self.__callback(index)
        except:
            pass


    def tabs(self, param):
        if isinstance(param, tuple):
            if len(param) > 2:
                import warnings
                warnings.warn('Incorrect data for tabs.', stacklevel=2)
            elif not param:
                self.visible = 0
                raise 'ValueError: incorrect data for tabs: no data'
            for i in param:
                if isinstance(i, list):
                    for q in i:
                        if not isinstance(q, unicode):
                            self.visible = 0
                            raise 'TypeError: items on the list must be unicode, not %s' % q.__class__.__name__
                    self.__items = i
                    if not i:
                        self.visible = 0
                elif callable(i):
                    self.__callback = i
                else:
                    self.visible = 0
                    raise 'TypeError: incorrect data for tabs. Parameters must be list or function, not %s' % i.__class__.__name__
        elif isinstance(param, list):
            for q in param:
                if not isinstance(q, unicode):
                    self.visible = 0
                    raise 'TypeError: items on the list must be unicode, not %s' % q.__class__.__name__
            self.__items = param
            if not param:
                self.visible = 0
        elif callable(param):
            self.__callback = param
        else:
            self.visible = 0
            raise 'TypeError: incorrect data for tabs. Parameters must be list or function, not %s' % param.__class__.__name__
        if self.__visible:
            appuifw.app.set_tabs(self.__items, self.__call)

    tabs = property(fset=tabs)


    def active_tab(self, pos):
        if not isinstance(pos, int):
            self.visible = 0
            raise 'TypeError: property "active_tab" must be int, not %s.' % pos.__class__.__name__
        if not self.__items:
            return
        if pos < 0:
            pos = max(0, len(self.__items) + pos)
        self.__pos = min(len(self.__items) - 1, pos)
        if self.__visible:
            appuifw.app.activate_tab(self.__pos)

    active_tab = property(lambda self: self.__pos, active_tab)
    

    def visible(self, v):
        if not self.__items:
            return
        self.__visible = bool(v)
        if not v:
            appuifw.app.set_tabs([], self.__call)
        else:
            for instance in Tabs._Tabs__instances:
                if instance is not self:
                    instance.__visible = 0
            appuifw.app.set_tabs(self.__items, self.__call)
            appuifw.app.activate_tab(self.__pos)
            self.__call(self.__pos)
    
    visible = property(lambda self: self.__visible, visible)
