#
# applist.py
# version 1.2.2


import e32

if e32.s60_version_info>=(3,0):
    import imp
    _applist = imp.load_dynamic('_applist', 'kf_applist.pyd')
    
else:
    import _applist

del e32, imp

def applist():
    return _applist.applist()

def applaunch(AppUID):
    return _applist.applaunch(AppUID)

#Many thanks to SajiSoft for providing help with converting C++ icon to Python Icon :D
import graphics
def icon(AppUID,size=48):
    img_ptr= _applist.fetchicon(AppUID,size,1)
    return graphics.Image.from_cfbsbitmap(img_ptr)
    
def iconmask(AppUID,size=48):
    img_ptr= _applist.fetchicon(AppUID,size,2)
    return graphics.Image.from_cfbsbitmap(img_ptr)

def new_sms(recipient):
	return _applist.launchsms(unicode(recipient))

KInbox=0x1002
KOutbox=0x1003
KDrafts=0x1004
KSent=0x1005
	
def launch_messaging(view=1):
	return _applist.launchinbox(view)
