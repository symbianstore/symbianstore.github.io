#coding: utf-8
# powlite_fm 1.3 final
#for Python 2.0
# by WyTHuK

import appuifw as a, os

class manager:
  def __init__(s): pass

  def show(s, dir=u''):
    dir = unicode(dir)
    a.app.body = a.Listbox([u'Please wait...'])
    a.e32.ao_yield()
    if os.path.isdir(dir):
      if dir != u'' and dir[-1]<>'\\': dir+='\\'
    if dir == u'':
      list = [d+'\\' for d in a.e32.drive_list()]
    else:
      try: list = [t[:1].upper()+t[1:] for t in os.listdir(dir)]
      except: list =[]
    a.app.title = dir
    dirs, files = [], []
    for i in list:
      path = dir+i
      pref = os.path.splitext(path)[1].lower()
      if os.path.isdir(path): dirs.append(i.upper())
      elif len(s.ext)==0 or pref in s.ext: files.append(i)
    dirs.sort(); files.sort()
    list = dirs
    if s.find <> 'dir': list+=files
    if len(dir)>0: list=[u'<<<']+list
    pop = a.selection_list(list, 1)
    if pop is None: s.path=None; return
    if list[pop] == u'<<<':
      dir=dir[:-1]
      dir = dir[:-len(dir.split('\\').pop())]
    elif s.find=='dir' and os.path.isdir(dir+list[pop]):
      pop2 = a.popup_menu([u'Open', u'Select'])
      if pop2==0: dir+=list[pop]
      elif pop2==1: s.path=dir+list[pop]+'\\'; return 1
    else: dir+=list[pop]
    s.path = dir
    if os.path.isfile(dir): return 1
    if len(dir)>=2 and dir[-1]<>'\\': dir+='\\'
    manager.show(s, dir)

  def AskUser(s, dir = u'', find='file', ext=[]):
    s.path, s.find, s.ext = dir, find, ext
    s.oldtitle, s.oldbody, s.oldscreen = a.app.title, a.app.body, a.app.screen
    a.app.screen = 'normal'
    manager.show(s, dir)
    a.app.title, a.app.body = s.oldtitle, s.oldbody
    return s.path