# -*- coding: utf-8 -*-
# Resize your JPG, GIF, PNG, BMP, and MBM pictures
# by Max << Crazy | Doctor
# Tested with Python for S60 2.0 and PowLite_FM 1.3 for Touch
import graphics,powlite_fm,appuifw
def ru(i): return i.decode('u8')
appuifw.note(ru('Choose an Image'),'conf')
x=powlite_fm.manager().AskUser(ext=['.bmp','.gif','.jpeg','.jpg','.mbm','.png'])
images=graphics.Image.open(x)
x=appuifw.query(ru('Width (pixels) :'),'number')
if x<1: x=1
y=appuifw.query(ru('Height (pixels) :'),'number')
if y<1: y=1
c=appuifw.query(ru('JPEG Quality, % :'),'number')
if c>100: c=100
d='no'#fast,default,best
s=appuifw.query(ru('New Image Filename :'),'text')
p=images.resize((x,y))
f=appuifw.popup_menu([ru('JPG'),ru('PNG')],ru('Format :'))
if f==0: p.save('e:\\Images\\'+str(s)+u'.jpg',quality=c)
else: p.save('e:\\Images\\'+str(s)+u'.png',compression=d)
appuifw.note(ru('Saved to E:\Images ...'),'info')
appuifw.app.set_exit()
  