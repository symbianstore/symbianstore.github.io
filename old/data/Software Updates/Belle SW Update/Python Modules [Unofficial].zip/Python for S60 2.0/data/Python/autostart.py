#emjebe

import struct
import os
class autostart:
 def _uid(s):
  try:
   import symbianutil as sy
   dt=open(s.file).read()
   x,x,uid,x,x,x = sy.e32imageinfo(dt)
   return '%08x'%uid
  except:
   x=open(s.file).read(12)
   x=[x[i].encode('hex') for i in range(11,7,-1)]
   return '%s'%''.join(x)
 def create(s, file):
  s.file=file
  uid= s._uid()
  path= '!:\\sys\\bin\\'
  name= str(os.path.basename(s.file))
  data='\x6b\x4a\x1f\x10\x00\x00\x00\x00\x00\x00\x00\x00\x19\xfd\x48\xe8\x01' + chr(32+len(name)*2) + '\x00\x01\x00\x02\x00' + chr(len(path)+len(name))*2 + path + name + '\x08\x00\x00\x00\x00\x00\x00\x00\x00\x14\x00' + chr(45+len(name)) + '\x00'
  new=u'c:\\private_101f875a_import_['+uid+'].rsc'
  fo=open(new,'wb')
  for i in data:
    fo.write(struct.pack('c',i ) )
  fo.close()
  print 'Done...!'
  print 'Add '+new+' on your PKG file. And set target become: '
  print new.replace('_','\\')

import powlite_fm
f= powlite_fm.manager().AskUser(ext=['.exe'])
if f:
  x=autostart()
  x.create(f)