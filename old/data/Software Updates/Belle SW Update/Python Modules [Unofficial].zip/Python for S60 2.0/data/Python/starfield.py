# coding: utf-8

#######################################################################
##                                                                   ##
##   ThroughTheUniverse2 v1.2.0 by mcsimb                            ##
##                                                                   ##
##   This is a screensaver script in Python, similar to the famous   ##
##   screen saver on Windows. Compatible with any branch of PyS60.   ##
##                                                                   ##
#######################################################################

# ThroughTheUniverse2.py 13-Sep-2012 22:43:23

import e32, sysinfo, time
import appuifw as ui
from random import *
from math import *
from graphics import Image

w, h = sysinfo.display_pixels()
w2, h2 = w/2, h/2
img = Image.new((w,h))
stars = []
run = 1
while len(stars)<150:
    stars.append([uniform(1,360), uniform(-320, 320), uniform(-320, 320)])

def redraw(rect):
    canvas.blit(img)

def exit(pos):
    global run
    run = 0

ui.app.screen = 'full'
ui.app.exit_key_handler = lambda: exit(0)
ui.app.orientation = 'portrait'
try: ui.app.directional_pad = False
except: pass
canvas = ui.Canvas(redraw_callback=redraw)
ui.app.body = canvas
canvas.bind(257, exit)

while run:
    k = 0
    img.clear(0x0)
    for i in stars:
        c = min(int(30000/i[0]),255)
        xpoint = 100*i[1]/i[0]
        ypoint = 100*i[2]/i[0]
        if -180<xpoint<180 and -320<ypoint<320:
            img.point((w2+xpoint, h2+ypoint), (c,c,c), width=min(int(400/i[0]), 5))
            i[0]-=2
            if i[0]==0: i[0] = -1
        else:
            stars[k] = [360.0, uniform(-320, 320), uniform(-320, 320)]
        k+=1
    canvas.blit(img)
    e32.ao_sleep(0.001)
    e32.reset_inactivity()
