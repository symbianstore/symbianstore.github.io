#CopyUID by DimaTROFIK.Program for copying UID to clipboard
def ru(x):return x.decode('utf-8')
import appuifw,applist,os,clipboard,e32
def uid():
    appuifw.app.title= u'\u0055\u0049\u0044'
    progi=[]
    ap=applist.applist()
    for ii in ap:
        if len(ii[1])!=0:
           progi.append(ii[1])
    ui=appuifw.selection_list(progi, 1)
    if ui==None:
        exit()
    else:
     appuifw.app.title = ru('Data type')
     fun = [ru("UID in Hex"), ru("UID in Dec"), ru('Name'), ru("EXE path")]
     xi = appuifw.popup_menu(fun, ru("Copy:")) 
     if xi == None:
       uid()
     elif xi == 0: 
       clipboard.Set(unicode(hex(ap[ui][0])))
       appuifw.note(ru('Application UID:\n') + unicode(hex(ap[ui][0])) + ru('\n> copied to clipboard!'))
     elif xi == 1 :
       clipboard.Set(unicode(ap[ui][0]))
       appuifw.note(ru('Application UID:\n') + unicode(ap[ui][0]) + ru('\n> copied to clipboard!'))
     elif xi == 2 :
       clipboard.Set((ap[ui][1]))
       appuifw.note(ru('Name:\n') + unicode(ap[ui][1]) + ru('\n> copied to clipboard!'))
     elif xi == 3 : 
       clipboard.Set((ap[ui][2]))
       appuifw.note(ru('Executable path:\n') + unicode(ap[ui][2]) + ru('\n> copied to clipboard!'))
     uid()
def exit():
    os.abort()
e32.ao_sleep(0.1,uid)
e32.Ao_lock().wait()