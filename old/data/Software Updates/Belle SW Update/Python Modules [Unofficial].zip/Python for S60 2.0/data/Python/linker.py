import appuifw, struct

global f

appuifw.app.body=f=appuifw.Text()

appuifw.app.screen = "normal"

def ru(x):
    return x.decode('utf-8')
        
f.add(ru('Linker v1.01'))
f.add(ru('\r\nAuthors:'))
f.add(ru('\r\n- intro (mathematics)'))
f.add(ru('\r\n- CODeRUS (interface)'))
f.add(ru('\r\nY2K8'))

def crc16ccitt(string, initialvalue = 0x0000, finalxor = 0x0000):

    value = initialvalue
    for c in string:
        value ^= (ord(c) << 8)
        for b in xrange(8):
            value <<= 1
            if value & 0x10000:
                value ^= 0x1021
            value &= 0xffff

    return value ^ finalxor
    
def uidcrc(uid1, uid2, uid3):
    uidstr = struct.pack("<LLL", uid1, uid2, uid3)
    evenchars = "".join([uidstr[n] for n in range(0, 12, 2)])
    oddchars  = "".join([uidstr[n] for n in range(1, 12, 2)])

    evencrc = crc16ccitt(evenchars)
    oddcrc  = crc16ccitt(oddchars)

    return (long(oddcrc) << 16) | evencrc

def uidstostring(uid1, uid2, uid3):

    crc = uidcrc(uid1, uid2, uid3)
    return struct.pack("<LLLL", uid1, uid2, uid3, crc)

def setuid():
   
   uuid3,fname=appuifw.multi_query(ru('Enter 8-digit application UID'),ru('Enter a link name'))
   f.add(ru('\r\n\r\nuid is: 0x')+uuid3)
   file="c:/"+fname
   uidstr = uidstostring(hextodec('10000037'),hextodec('10003a12'),hextodec(uuid3))
   logfile = open(file, 'w') 
   logfile.write(uidstr) 
   logfile.close()
   f.add(ru('\r\nFile ')+file+ru(' was successfully created!'))
      
def hextodec(s):
    hex="0x"+s
    return (eval(hex))

def exit():
    appuifw.app.set_exit()
  
appuifw.app.menu=[
(ru('Enter data'),setuid),
(ru('Exit'),exit)
]
appuifw.app.title=ru('Linker 1.01')

import e32

e32.ao_sleep(60)