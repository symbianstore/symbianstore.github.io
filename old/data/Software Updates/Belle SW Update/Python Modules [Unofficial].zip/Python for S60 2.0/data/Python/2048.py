import appuifw
appuifw.app.orientation='portrait'
appuifw.app.body.clear()
print 'Loading...'
import random,graphics,e32
from key_codes import EButton1Down as eDown
from key_codes import EButton1Up as eUp
q=graphics.Image.new((360,640))
q.clear(0xffffff)
a=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]
def newTyle():
 t=[]
 for x in range(4):
  for y in range(4):
   if a[x][y]==0:t.append((x,y))
 if len(t)!=0:
  tt=t[int(len(t)*random.random())]
  if random.random()<0.9:
   a[tt[0]][tt[1]]=1#means 2
  else:a[tt[0]][tt[1]]=2#means 4
newTyle()
def calldraw(*args):
 t.blit(q)
def splitTyleRight(*args):
 global a,score
 for x in range(4):
  tt=a[x]
  tq=[]
  for xx in range(4):
   if tt[xx]!=0:tq.append(tt[xx])
  tq=[0]*(4-len(tq))+tq
  tt=tq
  #appuifw.note(unicode(tq))
  ttemp=False
  if tt[3]==tt[2]!=0:
   tt[3]+=1
   tt[2]=0
   score+=tyle_num[tt[3]]
  elif tt[2]==tt[1]!=0:
   tt[2]+=1
   tt[1]=0
   score+=tyle_num[tt[2]]
  if tt[1]==tt[0]!=0:
   tt[1]+=1
   tt[0]=0
   score+=tyle_num[tt[1]]
  #appuifw.note(unicode(tt))
  tq=[]
  for xx in range(4):
   if tt[xx]!=0:tq.append(tt[xx])
  tq=[0]*(4-len(tq))+tq
  #appuifw.note(unicode(tq))
  a[x]=tq
def splitTyleLeft(*args):
 global a,score
 for x in range(4):
  tt=a[x]
  tq=[]
  for xx in range(4):
   if tt[xx]!=0:tq.append(tt[xx])
  tq+=[0]*(4-len(tq))
  #appuifw.note(unicode(tq))
  tt=tq
  if tt[0]==tt[1]!=0:
   tt[0]+=1
   tt[1]=0
   score+=tyle_num[tt[0]]
  elif tt[1]==tt[2]!=0:
   tt[1]+=1
   tt[2]=0
   score+=tyle_num[tt[1]]
  if tt[2]==tt[3]!=0:
   tt[2]+=1
   tt[3]=0
   score+=tyle_num[tt[2]]
  #appuifw.note(unicode(tq))
  tq=[]
  for xx in range(4):
   if tt[xx]!=0:tq.append(tt[xx])
  tq+=[0]*(4-len(tq))
  #appuifw.note(unicode(tq))
  a[x]=tq
def splitTyleUp(*args):
 global a,score
 for y in range(4):
  tt=[a[0][y],a[1][y],a[2][y],a[3][y]]
  tq=[]
  for xx in range(4):
   if tt[xx]!=0:tq.append(tt[xx])
  tq+=[0]*(4-len(tq))
  tt=tq
  #appuifw.note(unicode(tq))
  if tt[0]==tt[1]!=0:
   tt[0]+=1
   tt[1]=0
   score+=tyle_num[tt[0]]
  elif tt[1]==tt[2]!=0:
   tt[1]+=1
   tt[2]=0
   score+=tyle_num[tt[1]]
  if tt[2]==tt[3]!=0:
   tt[2]+=1
   tt[3]=0
   score+=tyle_num[tt[2]]
  #appuifw.note(unicode(tt))
  tq=[]
  for xx in range(4):
   if tt[xx]!=0:tq.append(tt[xx])
  tq+=[0]*(4-len(tq))
  #appuifw.note(unicode(tq))
  a[0][y],a[1][y],a[2][y],a[3][y]=tq
def splitTyleDown(*args):
 global a,score
 for y in range(4):
  tt=[a[0][y],a[1][y],a[2][y],a[3][y]]
  tq=[]
  for xx in range(4):
   if tt[xx]!=0:tq.append(tt[xx])
  tq=[0]*(4-len(tq))+tq
  tt=tq
  #appuifw.note(unicode(tq))
  if tt[3]==tt[2]!=0:
   tt[3]+=1
   tt[2]=0
   score+=tyle_num[tt[3]]
  elif tt[2]==tt[1]!=0:
   tt[2]+=1
   tt[1]=0
   score+=tyle_num[tt[2]]
  if tt[1]==tt[0]!=0:
   tt[1]+=1
   tt[0]=0
   score+=tyle_num[tt[1]]
  #appuifw.note(unicode(tt))
  tq=[]
  for xx in range(4):
   if tt[xx]!=0:tq.append(tt[xx])
  tq=[0]*(4-len(tq))+tq
  #appuifw.note(unicode(tq))
  a[0][y],a[1][y],a[2][y],a[3][y]=tq
tyle_num=(0,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072)
tyle_decode=[]
for x in tyle_num:tyle_decode.append(unicode(x))
tyle_decode=tuple(tyle_decode)
tyles=((),(0xffffff,(220,220,220),26,20,40,0xeee4da),(0xffffff,(210,210,210),26,20,40,0xede0c8),(0xf9f6f2,0xf2b179,26,20,40),(0xf9f6f2,0xf59563,15,20,40),(0xf9f6f2,0xf67c5f,16,20,40),(0xf9f6f2,0xf65e3b,16,20,40),(0xf9f6f2,0xedcf72,8,20,35),(0xf9f6f2,0xedcc61,8,20,35),(0xf9f6f2,0xedc850,8,20,35),(0xf9f6f2,0xedc53f,5,18,30),(0xf9f6f2,0xedc22e,5,18,30),(0xf9f6f2,0x3c3a32,5,18,30),(0xf9f6f2,0x3c3a32,5,18,30),(0xf9f6f2,0x3c3a32,4,16,25),(0xf9f6f2,0x3c3a32,4,16,25),(0xf9f6f2,0x3c3a32,4,16,25),(0xf9f6f2,0x3c3a32,4,14,20))
back_color=0xeee4da
score=0
best=0
best_cache=0
makeTyle=True
def RedrawTyle():
 global best_cache,makeTyle
 #appuifw.note(unicode(makeTyle))
 if makeTyle:
  newTyle()
  makeTyle=False  
 q.rectangle((30,170,330,470),back_color,back_color)
 q.rectangle((30,105,250,135),0xffffff,0xffffff)
 q.text((30,135),u'Score: '+unicode(score),0,font=(None,30,None))
 if best!=best_cache:
  q.rectangle((30,65,250,95),0xffffff,0xffffff)
  q.text((30,95),u'Best: '+unicode(best),0,font=(None,30,None))
  best_cache=best
 q.text((252,135),u'Undo',0,font=(None,35,None))
 #appuifw.note(unicode(a))
 for x in range(4):
  for y in range(4):
   #if a[x][y]==0:
    #q.rectangle((30+75*x,170+75*y,105+75*x,245+75*y),back_color,back_color)
   if a[x][y]!=0:
    tyle=tyles[a[x][y]]
    q.rectangle((30+75*x,170+75*y,105+75*x,245+75*y),tyle[1],tyle[1])
    q.text((30+75*x+tyle[2],200+75*y+tyle[3]),tyle_decode[a[x][y]],tyle[0],font=(None,tyle[4],None))
drctn=0
winner=False
def check4Lose():
 for x in range(4):
  for y in range(4):
   if a[x][y]==0:return False
 for x in range(3):
  for y in range(3):
   if a[x][y]==a[x+1][y] or a[x][y]==a[x][y+1]:return False
 for x in range(3):
  if a[x][3]==a[x+1][3]:return False
  if a[3][x]==a[3][x+1]:return False
 return True
def check4Win():
 global winner
 if winner:return
 for x in range(4):
  for y in range(4):
   if a[x][y]==11:
    appuifw.note(u'Winner!!!')
    appuifw.note(u'Champion!!!')
    appuifw.note(u'2048 Hero!!!')
    winner=True
    return
ab=[]
def RefreshArray():
 global smth_input,makeTyle,ab,undo_data
 smth_input=False
 makeTyle=False
 undo_data=[int(score),[[a[0][0],a[0][1],a[0][2],a[0][3]],[a[1][0],a[1][1],a[1][2],a[1][3]],[a[2][0],a[2][1],a[2][2],a[2][3]],[a[3][0],a[3][1],a[3][2],a[3][3]]]]
 #appuifw.note(unicode(drctn))
 ab=str(a)
 if drctn==4:
  splitTyleRight()
 elif drctn==3:
  splitTyleLeft()
 elif drctn==2:
  splitTyleUp()
 elif drctn==1:
  splitTyleDown()
 if str(a)==ab:makeTyle=False
 else:makeTyle=True
 #appuifw.note(u'direct '+unicode(makeTyle))
 #appuifw.note(unicode(a)+'\n'+unicode(ab))
 if check4Lose():
  appuifw.note(u'Game over!','error')
  if score>best:
   global best
   best=score
   SaveBest()
 check4Win()
downe=[0,0]
restarting=False
def NewGame():
 if not appuifw.query(u'Are you sure to restart?','query'):return
 NewGameFactory()
def NewGameFactory():
 global a,score,restarting,best,makeTyle,undo_data,winner
 restarting=True
 makeTyle=True
 winner=False
 a=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]
 undo_data=[0,a]
 if score>best:
  best=score
  SaveBest()
 score=0
 newTyle()
 RedrawTyle()
 t.blit(q)
 #t.bind(eDown,key_down)
 #t.bind(eUp,key_up)
undo_data=[]
def Undo():
 #appuifw.note(unicode(undo_data))
 global undo_data
 if len(undo_data)==0:return appuifw.note(u'Undo works for last move only!!!','error')
 global score,a
 score=undo_data[0]
 a=undo_data[1]
 undo_data=[]
 RedrawTyle()
 t.blit(q)
 #appuifw.note(u'undo')
prepare_restart=False
prepare_undo=False
def key_down(coord):
 global downe,prepare_restart,prepare_undo
 if 20<coord[0]<170 and 480<coord[1]<550:prepare_restart=True
 if 230<coord[0]<350 and 80<coord[1]<135:prepare_undo=True
 downe=[coord[0],coord[1]]
def get_place(coord,center):
 if coord[0]>center[0]:
  if coord[1]>center[1]:
   return 4
  else:
   return 1
 else:
  if coord[1]>center[1]:
   return 3
  else:return 2
def key_up(coord):
 global downe,drctn,smth_input,restarting,prepare_restart,prepare_undo
 line_len=pow(pow(downe[0]-coord[0],2)+pow(downe[1]-coord[1],2),0.5)
 if line_len<25:
  if prepare_undo:
   prepare_undo=False
   return Undo()
  if prepare_restart:
   prepare_restart=False
   return NewGame()
  if 280<coord[0]<360 and 0<coord[1]<90:return Shutdown()
  if 300<coord[0]<360 and 600<coord[1]<640:
   appuifw.note(u'2048 v1.2\nAuthor: Gabriele Cirulli')
   return appuifw.note(u'Ported by GOleg\no.a.gromyak@gmail')
 if line_len<38:return
 prepare_restart=False
 prepare_undo=False
 upe=[coord[0],coord[1]]
 if upe==downe:return
 center=[abs((downe[0]+upe[0])/2),abs((downe[1]+upe[1])/2)]
 td,tu=get_place(downe,center),get_place(upe,center)
 c=center
 #appuifw.note(unicode((tu,td)))
 if tu==1:
  if abs(upe[0]-c[0])>abs(upe[1]-c[1]):
   drctn=1
  else:
   drctn=3
 elif tu==2:
  if abs(upe[0]-c[0])>abs(upe[1]-c[1]):
   drctn=2
  else:
   drctn=3
 elif tu==3:
  if abs(upe[0]-c[0])>abs(upe[1]-c[1]):
   drctn=2
  else:
   drctn=4
 elif tu==4:
  if upe[0]-c[0]>abs(upe[1]-c[1]):
   drctn=1
  else:
   drctn=4
 smth_input=True
def LoadBest():
 global best
 try:
  f=open('e:\\python\\2048.best')
  best=int(f.read(),16)
  f.close()
 except:
  appuifw.note(u'File destroyed!!!\n=>Best set to 0','error')
def SaveBest():
 try:
  f=open('e:\\python\\2048.best','w')
  f.write(hex(best))
  f.close()
 except:
  appuifw.note(u'Error writing best to file\nCall GOleg!!!')
 appuifw.note(u'Best score!')
err_load=True
def LoadGameFromFile():
 try:
  global a,score,makeTyle,undo_data,err_load
  f=open('e:\\python\\2048.sv')
  import pickle
  tload=pickle.load(f)
  del pickle
  score=int(tload[0])
  a=tload[1]
  undo_data=tload[2]
  makeTyle=False
  err_load=False
 except:
  appuifw.note(u'Error loading game!!!','error')
def PauseGame2File():
 try:
  f=open('e:\\python\\2048.sv','w')
  import pickle
  pickle.dump([score,a,undo_data],f)
  f.close()
 except:
  appuifw.note(u'Error saving game!!!','error')
  return appuifw.note(u'If you see this again, call GOleg')
LoadBest()
LoadGameFromFile()
q.text((30,520),u'Restart',0,(None,40,None))
q.line((300-4,30,330-4,60),0,0,width=4)
q.line((300-4,60,330-4,30),0,0,width=4)
q.text((280,620),u'Info',0,font=(None,25,None))
RedrawTyle()
ttext=appuifw.app.body.clear
appuifw.app.screen='full'
appuifw.app.directional_pad=False
appuifw.app.body=t=appuifw.Canvas(redraw_callback=calldraw)
appuifw.app.screen='full'
appuifw.app.directional_pad=False
ttext()
if err_load:NewGameFactory()
t.bind(eDown,key_down)
t.bind(eUp,key_up)
t.clear(0)
t.blit(q)
smth_input=False
playing=True
def Shutdown():
 global playing,smth_input,best
 playing=False
 smth_input=False
 if score>best:
  best=score
  SaveBest()
 PauseGame2File()
 appuifw.app.set_exit()
try:
 while playing:
  if smth_input:
   RefreshArray()
   RedrawTyle()
   t.blit(q)
  e32.ao_sleep(0.05)
except:
 f=open('e:\\python\\000000000000','w')
 import sys
 f.write(str(sys.exc_info()))
 f.close()
 appuifw.note(u'qq')