                     ,---.           ,---.                         
                    / /"`.\.--"""--./,'"\ \                        
                    \ \    _       _    / /                        
                     `./  / __   __ \  \,'                         
                      /    /_O)_(_O\    \                          
                      |  .-'  ___  `-.  |                          
                   .--|       \_/       |--.                       
                 ,'    \   \   |   /   /    `.                     
                /       `.  `--^--'  ,'       \                    
             .-"""""-.    `--.___.--'     .-"""""-.                
.-----------/         \------------------/         \--------------.
| .---------\         /----------------- \         /------------. |
| |          `-`--`--'                    `--'--'-'             | |
| | File Certificate Store + November 2021 Update for Symbian^3 | |
| |                                                             | |
| |   This is a new, updated one. It includes every important   | |
| |   CA root certificate (from Ubuntu and Windows 10 latest    | |
| |   build combined, including "ISRG Root X1"). It is based    | |
| |   on CACerts.dat file from the original latest Nokia 808    | |
| |   firmware, and tested on Nokia E7-00 (Belle). With this,   | |
| |   all TLS 1.0 and most of TLS 1.1 websites should work.     | |
| |                                                             | |
| |                  How to apply this update:                  | |
| |              Open ROMPatcher, enable Open4All,              | |
| |      and copy-replace C:\private\101F72A6\CACerts.dat       | |
| |_____________________________________________________________| |
|_________________________________________________________________|
                   )__________|__|__________(                      
      Created by  |            ||            |  Distributed via    
   Nuru TaşDemir  |____________||____________|   www.symwld.com    
                    ),-----.(      ),-----.(                       
                  ,'   ==.   \    /  .==    `.                     
                 /            )  (            \                    
                 `==========='    `==========='                    